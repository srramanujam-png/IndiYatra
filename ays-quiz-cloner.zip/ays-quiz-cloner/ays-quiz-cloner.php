<?php
/**
 * Plugin Name: AYS Quiz Cloner
 * Description: Clone AYS Pro Quiz quizzes in bulk and replace their CSS field with new code.
 * Version:     1.0.0
 * Author:      IndiYatra
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AYS_Quiz_Cloner {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
    }

    public function add_menu() {
        add_management_page(
            'AYS Quiz Cloner',
            'Quiz Cloner',
            'manage_options',
            'ays-quiz-cloner',
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_styles( $hook ) {
        if ( $hook !== 'tools_page_ays-quiz-cloner' ) return;
        wp_enqueue_style( 'wp-codemirror' );
    }

    /* ── helpers ─────────────────────────────────── */

    private function find_quiz_table() {
        global $wpdb;
        $candidates = [
            $wpdb->prefix . 'ays_quizes',      // most common (yes, typo in plugin)
            $wpdb->prefix . 'ays_quizzes',
            $wpdb->prefix . 'aysquiz_quizes',
            $wpdb->prefix . 'aysquiz_quizzes',
        ];
        foreach ( $candidates as $t ) {
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) === $t ) {
                return $t;
            }
        }
        return null;
    }

    private function get_columns( $table ) {
        global $wpdb;
        return $wpdb->get_results( "DESCRIBE `{$table}`" );
    }

    private function get_quizzes( $table ) {
        global $wpdb;
        return $wpdb->get_results( "SELECT * FROM `{$table}` ORDER BY id DESC", ARRAY_A );
    }

    private function clone_quiz( $table, $id, $css_field, $new_css ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ),
            ARRAY_A
        );
        if ( ! $row ) return false;

        unset( $row['id'] );

        // Append " (Clone)" to title — handles common column names
        foreach ( [ 'title', 'name', 'quiz_title' ] as $title_col ) {
            if ( isset( $row[ $title_col ] ) ) {
                $row[ $title_col ] = $row[ $title_col ] . ' (Clone)';
                break;
            }
        }

        // Replace CSS
        if ( $css_field && array_key_exists( $css_field, $row ) ) {
            $row[ $css_field ] = $new_css;
        }

        return $wpdb->insert( $table, $row ) !== false;
    }

    /* ── page ────────────────────────────────────── */

    public function render_page() {
        global $wpdb;

        $table   = $this->find_quiz_table();
        $message = '';
        $error   = '';

        // ── handle submission ──────────────────────
        if (
            isset( $_POST['ays_cloner_nonce'] ) &&
            wp_verify_nonce( $_POST['ays_cloner_nonce'], 'ays_cloner_action' )
        ) {
            $quiz_ids  = array_map( 'intval', (array) ( $_POST['quiz_ids']  ?? [] ) );
            $css_field = sanitize_key( $_POST['css_field'] ?? '' );
            $new_css   = stripslashes( $_POST['new_css']   ?? '' );

            if ( empty( $quiz_ids ) ) {
                $error = 'Please select at least one quiz.';
            } elseif ( ! $css_field ) {
                $error = 'Please select the CSS column to replace.';
            } else {
                $count = 0;
                foreach ( $quiz_ids as $id ) {
                    if ( $this->clone_quiz( $table, $id, $css_field, $new_css ) ) {
                        $count++;
                    }
                }
                $message = "✓ Successfully cloned {$count} quiz" . ( $count !== 1 ? 'zes' : '' ) . '.';
            }
        }

        // ── gather data ────────────────────────────
        $quizzes     = $table ? $this->get_quizzes( $table )   : [];
        $columns_raw = $table ? $this->get_columns( $table )   : [];
        $col_names   = array_column( $columns_raw, 'Field' );
        $css_cols    = array_values( array_filter( $col_names, fn( $c ) =>
            stripos( $c, 'css' ) !== false || stripos( $c, 'style' ) !== false
        ) );

        // Title-like columns for the table preview
        $title_col = 'id';
        foreach ( [ 'title', 'name', 'quiz_title', 'quiz_name' ] as $t ) {
            if ( in_array( $t, $col_names, true ) ) { $title_col = $t; break; }
        }

        ?>
        <div class="wrap" id="ays-cloner-wrap">
            <h1>🧬 AYS Quiz Cloner</h1>

            <?php if ( $message ) : ?>
                <div class="notice notice-success is-dismissible"><p><?= esc_html( $message ) ?></p></div>
            <?php endif; ?>
            <?php if ( $error ) : ?>
                <div class="notice notice-error is-dismissible"><p><?= esc_html( $error ) ?></p></div>
            <?php endif; ?>

            <?php if ( ! $table ) : ?>
                <div class="notice notice-error">
                    <p><strong>AYS Quiz table not found.</strong> Make sure AYS Pro Quiz is installed and active.</p>
                    <p>Tables starting with <code><?= esc_html( $wpdb->prefix . 'ays' ) ?></code> on this site:</p>
                    <p><code><?php
                        $found = $wpdb->get_col( "SHOW TABLES LIKE '{$wpdb->prefix}ays%'" );
                        echo esc_html( $found ? implode( ', ', $found ) : '(none)' );
                    ?></code></p>
                </div>
            <?php else : ?>

                <p style="color:#555;">
                    Detected table: <code><?= esc_html( $table ) ?></code> &nbsp;·&nbsp;
                    <?= count( $quizzes ) ?> quizzes found.
                </p>

                <?php if ( ! $css_cols ) : ?>
                    <div class="notice notice-warning">
                        <p>No column with "css" or "style" in its name was found. All columns are listed in the CSS field dropdown — pick the right one.</p>
                    </div>
                <?php endif; ?>

                <form method="post" id="clone-form">
                    <?php wp_nonce_field( 'ays_cloner_action', 'ays_cloner_nonce' ); ?>

                    <!-- ── Quiz table ── -->
                    <h2>1 · Select quizzes to clone</h2>
                    <table class="wp-list-table widefat fixed striped" style="max-width:860px;">
                        <thead>
                            <tr>
                                <th style="width:36px;">
                                    <input type="checkbox" id="chk-all" title="Select all" />
                                </th>
                                <th style="width:50px;">ID</th>
                                <th>Title</th>
                                <?php if ( $css_cols ) : ?>
                                    <th>Current CSS (preview)</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $quizzes as $q ) : ?>
                            <tr>
                                <td><input type="checkbox" name="quiz_ids[]" value="<?= esc_attr( $q['id'] ) ?>" class="quiz-chk" /></td>
                                <td><?= esc_html( $q['id'] ) ?></td>
                                <td><?= esc_html( $q[ $title_col ] ?? '—' ) ?></td>
                                <?php if ( $css_cols ) :
                                    $preview = $q[ $css_cols[0] ] ?? '';
                                    $preview = mb_substr( $preview, 0, 120 );
                                ?>
                                    <td><code style="font-size:11px;color:#555;"><?= esc_html( $preview ?: '(empty)' ) ?><?= mb_strlen( $q[ $css_cols[0] ] ?? '' ) > 120 ? '…' : '' ?></code></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- ── CSS field ── -->
                    <h2 style="margin-top:32px;">2 · Choose the CSS column &amp; enter new CSS</h2>
                    <table class="form-table" style="max-width:860px;">
                        <tr>
                            <th style="width:200px;"><label for="css_field">CSS column</label></th>
                            <td>
                                <select name="css_field" id="css_field" style="min-width:220px;">
                                    <option value="">— select column —</option>
                                    <?php if ( $css_cols ) : ?>
                                        <optgroup label="Likely CSS columns">
                                            <?php foreach ( $css_cols as $c ) : ?>
                                                <option value="<?= esc_attr( $c ) ?>"><?= esc_html( $c ) ?></option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endif; ?>
                                    <optgroup label="All columns">
                                        <?php foreach ( $col_names as $c ) : ?>
                                            <?php if ( ! in_array( $c, $css_cols, true ) ) : ?>
                                                <option value="<?= esc_attr( $c ) ?>"><?= esc_html( $c ) ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </optgroup>
                                </select>
                                <p class="description">Pick the column that holds the quiz CSS. If you see "css", "styles", or similar — that's it.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="new_css">New CSS code</label></th>
                            <td>
                                <textarea
                                    name="new_css"
                                    id="new_css"
                                    rows="14"
                                    style="width:100%;max-width:680px;font-family:monospace;font-size:13px;"
                                    placeholder="Paste your new CSS here…"
                                ></textarea>
                                <p class="description">This CSS will be written into the cloned quizzes. The originals are not changed.</p>
                            </td>
                        </tr>
                    </table>

                    <!-- ── Submit ── -->
                    <p style="margin-top:24px;">
                        <input
                            type="submit"
                            class="button button-primary button-hero"
                            value="Clone selected quizzes"
                            id="submit-btn"
                            disabled
                        />
                        <span id="selection-count" style="margin-left:12px;color:#555;font-size:13px;"></span>
                    </p>
                </form>

            <?php endif; ?>
        </div>

        <script>
        (function () {
            var chkAll = document.getElementById('chk-all');
            var boxes  = document.querySelectorAll('.quiz-chk');
            var btn    = document.getElementById('submit-btn');
            var count  = document.getElementById('selection-count');

            function updateState() {
                var n = document.querySelectorAll('.quiz-chk:checked').length;
                btn.disabled = n === 0;
                count.textContent = n ? n + ' quiz' + (n > 1 ? 'zes' : '') + ' selected' : '';
                if (chkAll) chkAll.indeterminate = n > 0 && n < boxes.length;
                if (chkAll) chkAll.checked = n === boxes.length && boxes.length > 0;
            }

            boxes.forEach(function(b) { b.addEventListener('change', updateState); });

            if (chkAll) {
                chkAll.addEventListener('change', function () {
                    boxes.forEach(function(b) { b.checked = chkAll.checked; });
                    updateState();
                });
            }

            updateState();
        })();
        </script>
        <?php
    }
}

new AYS_Quiz_Cloner();
